

function encrypted() {
    var encryptedBase64Key = 'bXVzdGJlMTZieXRlc2tleQ==';
    var parsedBase64Key = CryptoJS.enc.Base64.parse(encryptedBase64Key);
    var encryptedData = null;
    var plaintText = document.getElementById("password").value;
    encryptedData = CryptoJS.AES.encrypt(plaintText, parsedBase64Key, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7
    });
    document.write('encryptedData = ' + encryptedData);
}